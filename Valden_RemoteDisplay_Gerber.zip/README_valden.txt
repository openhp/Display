Valden Heat Pump Controller v1.x:
The Valden Heat Pump controller is an open source platform to precisely control heat pumps. This controller can be used for the automation of newly built Heat Pumps (HPs), as a repair controller for old systems or as control system for performing experiments on refrigeration equipment.


Valden: Remote Display v1.x:
This device allows you to control the Valden Heat Pump via remote display. Display can be used with a signal cable up to a few hundred meters long. As well as the controller this display is an also open product with available gerber and source code.


Valden: Service Display:
The Service Display is a quickly assembled tool, that allows you to connect Valden Heat Pump Controller to get maximum available information from sensors and show it graphically.


https://github.com/openhp/


License
(c) 2018-2021 D.A.A. All rights reserved; gonzho@web.de;

Text, media and other materials licensed under CC-BY-SA License v4.0.
Attribution: You must clearly attribute Valden Heat Pump Controller (https://github.com/openhp/HeatPumpController/) original work in any derivative works.
Share and Share Alike: If you make modifications or additions to the content you re-use, you must license them under the CC-BY-SA License v4.0 or later.
Indicate changes: If you make modifications or additions, you must indicate in a reasonable fashion that the original work has been modified.
You are free: to share and adapt the material for any purpose, even commercially, as long as you follow the license terms.

The firmware source code licensed under GPLv3.
This product is distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU General Public License for more details.

For third-party libraries licenses used in this product please refer to those libraries.

Author

gonzho@web.de (c) 2018-2021

https://github.com/openhp/
